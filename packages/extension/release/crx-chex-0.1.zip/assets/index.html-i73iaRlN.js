import{j as p,q as E,a as m,i as L,k as f,l as w,v as S,t as k,p as x,r as C,f as $}from"./goober.modern-DEbODEY5.js";(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))g(e);new MutationObserver(e=>{for(const t of e)if(t.type==="childList")for(const r of t.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&g(r)}).observe(document,{childList:!0,subtree:!0});function d(e){const t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?t.credentials="include":e.crossOrigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",t}function g(e){if(e.ep)return;e.ep=!0;const t=d(e);fetch(e.href,t)}})();var I=k("<div><h1>Sign In</h1><button></button><div>");const P=p`
  width: 300px;
  padding: 20px;
  background: white;
  color: black;
`,O=p`
  margin: 0 0 20px 0;
  font-size: 18px;
`,N=p`
  width: 100%;
  padding: 10px;
  background: black;
  color: white;
  border: none;
  font-size: 14px;
  cursor: pointer;
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,A=p`
  margin-top: 15px;
  font-size: 12px;
`;function G(n){const[a,d]=m(!1),[g,e]=m(""),[t,r]=m(!1),v=async()=>{d(!0),e("Signing in with Google..."),r(!1);try{const o=await chrome.identity.getAuthToken({interactive:!0}),{token:s}=o;if(!s)throw new Error("Failed to get authentication token");const i=await(await fetch(`https://www.googleapis.com/oauth2/v2/userinfo?access_token=${s}`)).json();console.log(i),n.onLogin&&n.onLogin(s),e(`Welcome, ${i.email}!`),r(!1),await chrome.storage.local.set({userEmail:i.email,userName:i.name,accessToken:s,isLoggedIn:!0,loginTime:Date.now()})}catch(o){console.error("Google login error:",o),e("Sign-in failed. Please try again."),r(!0)}finally{d(!1)}};return L(async()=>{console.log("Checking login status");try{const o=await chrome.storage.local.get(["isLoggedIn","userEmail"]);o.isLoggedIn&&o.userEmail&&(e(`Welcome back, ${o.userEmail}!`),r(!1))}catch(o){console.error("Error checking login status:",o)}}),(()=>{var o=I(),s=o.firstChild,c=s.nextSibling,i=c.nextSibling;return f(o,P),f(s,O),c.$$click=v,f(c,N),w(c,()=>a()?"Signing in...":"Sign in with Google"),w(i,g),S(l=>{var h=a(),y=`${A} color: ${t()?"red":"green"};`;return h!==l.e&&(c.disabled=l.e=h),y!==l.t&&f(i,l.t=y),l},{e:void 0,t:void 0}),o})()}E(["click"]);let u=null;function _(){const n=C();u&&(u.textContent=n)}function b(){const n=document.getElementById("app");if(!n){console.error("Popup app container not found");return}u=document.createElement("style"),u.setAttribute("data-styled-components",""),document.head.appendChild(u),x(()=>$(G,{}),n),_()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",b):b();
