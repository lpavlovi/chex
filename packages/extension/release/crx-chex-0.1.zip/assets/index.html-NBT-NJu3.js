import{j as p,v,a as m,i as L,k as x,l as f,n as w,w as S,x as k,y as C,t as $,q as I,r as P,f as O}from"./goober.modern-Csar2pva.js";(function(){const a=document.createElement("link").relList;if(a&&a.supports&&a.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))g(e);new MutationObserver(e=>{for(const t of e)if(t.type==="childList")for(const r of t.addedNodes)r.tagName==="LINK"&&r.rel==="modulepreload"&&g(r)}).observe(document,{childList:!0,subtree:!0});function d(e){const t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?t.credentials="include":e.crossOrigin==="anonymous"?t.credentials="omit":t.credentials="same-origin",t}function g(e){if(e.ep)return;e.ep=!0;const t=d(e);fetch(e.href,t)}})();var N=$("<div><h1>Sign In</h1><button></button><div>");const A=p`
  width: 300px;
  padding: 20px;
  background: white;
  color: black;
`,G=p`
  margin: 0 0 20px 0;
  font-size: 18px;
`,_=p`
  width: 100%;
  padding: 10px;
  background: black;
  color: white;
  border: none;
  font-size: 14px;
  cursor: pointer;
  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`,z=p`
  margin-top: 15px;
  font-size: 12px;
`;function T(n){const[a,d]=m(!1),[g,e]=m(""),[t,r]=m(!1),b=async()=>{d(!0),e("Signing in with Google..."),r(!1);try{const o=await chrome.identity.getAuthToken({interactive:!0}),{token:s}=o;if(!s)throw new Error("Failed to get authentication token");const i=await(await fetch(`https://www.googleapis.com/oauth2/v2/userinfo?access_token=${s}`)).json();console.log(i),n.onLogin&&n.onLogin(s),e(`Welcome, ${i.email}!`),r(!1),await chrome.storage.local.set({userEmail:i.email,userName:i.name,accessToken:s,isLoggedIn:!0,loginTime:Date.now()})}catch(o){console.error("Google login error:",o),e("Sign-in failed. Please try again."),r(!0)}finally{d(!1)}};return L(async()=>{console.log("Checking login status");try{const o=await chrome.storage.local.get(["isLoggedIn","userEmail"]);o.isLoggedIn&&o.userEmail&&(e(`Welcome back, ${o.userEmail}!`),r(!1))}catch(o){console.error("Error checking login status:",o)}}),(()=>{var o=x(N),s=o.firstChild,c=s.nextSibling,i=c.nextSibling;return f(o,A),f(s,G),c.$$click=b,f(c,_),w(c,()=>a()?"Signing in...":"Sign in with Google"),w(i,g),S(l=>{var h=a(),y=`${z} color: ${t()?"red":"green"};`;return h!==l.e&&k(c,"disabled",l.e=h),y!==l.t&&f(i,l.t=y),l},{e:void 0,t:void 0}),C(),o})()}v(["click"]);let u=null;function j(){const n=P();u&&(u.textContent=n)}function E(){const n=document.getElementById("app");if(!n){console.error("Popup app container not found");return}u=document.createElement("style"),u.setAttribute("data-styled-components",""),document.head.appendChild(u),I(()=>O(T,{}),n),j()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",E):E();
