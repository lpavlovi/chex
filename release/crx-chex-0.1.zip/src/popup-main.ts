import { createComponent } from "solid-js";
import { render } from "solid-js/web";
import { LoginPopup } from "./popup/LoginPopup";
import { extractCss } from "solid-styled-components";

let styleElement: HTMLStyleElement | null = null;

function updateStyles() {
  const css = extractCss();
  if (styleElement) {
    styleElement.textContent = css;
  }
}

function mountPopupApp() {
  const container = document.getElementById("app");
  if (!container) {
    console.error("Popup app container not found");
    return;
  }

  // Create and inject style element
  styleElement = document.createElement("style");
  styleElement.setAttribute("data-styled-components", "");
  document.head.appendChild(styleElement);

  // Initial render
  render(() => createComponent(LoginPopup, {
    onLogin: (credentials) => {
      console.log("Login attempted with:", credentials.email);
      // You can add additional login logic here
    }
  }), container);

  // Initial style extraction
  updateStyles();

  // Set up HMR for style updates
  if (import.meta.hot) {
    import.meta.hot.accept("./popup/LoginPopup", () => {
      // Re-extract styles when LoginPopup component changes
      updateStyles();
    });
  }
}

// Auto-mount when DOM is ready
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", mountPopupApp);
} else {
  mountPopupApp();
}

// Cleanup on unmount
if (import.meta.hot) {
  import.meta.hot.dispose(() => {
    if (styleElement && styleElement.parentNode) {
      styleElement.parentNode.removeChild(styleElement);
    }
  });
}
