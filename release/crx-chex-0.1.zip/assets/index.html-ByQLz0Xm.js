import{u as i,g as q,b as f,d as A,a as z,t as w,c as a,i as S,h,M as D,f as B,r as F}from"./index-DY_CammD.js";(function(){const n=document.createElement("link").relList;if(n&&n.supports&&n.supports("modulepreload"))return;for(const t of document.querySelectorAll('link[rel="modulepreload"]'))l(t);new MutationObserver(t=>{for(const r of t)if(r.type==="childList")for(const c of r.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&l(c)}).observe(document,{childList:!0,subtree:!0});function x(t){const r={};return t.integrity&&(r.integrity=t.integrity),t.referrerPolicy&&(r.referrerPolicy=t.referrerPolicy),t.crossOrigin==="use-credentials"?r.credentials="include":t.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function l(t){if(t.ep)return;t.ep=!0;const r=x(t);fetch(t.href,r)}})();var R=w("<h1>Welcome to Chex"),W=w('<form><div><label for=email>Email</label><input id=email type=email placeholder="Enter your email"required></div><div><label for=password>Password</label><input id=password type=password placeholder="Enter your password"required></div><button type=submit>'),Y=w("<div>");const j=i`
  width: 320px;
  min-height: 400px;
  padding: 20px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 20px;
`,G=i`
  font-size: 24px;
  font-weight: 600;
  margin: 0;
  text-align: center;
`,K=i`
  display: flex;
  flex-direction: column;
  gap: 16px;
  width: 100%;
  max-width: 280px;
`,_=i`
  display: flex;
  flex-direction: column;
  gap: 8px;
`,I=i`
  font-size: 14px;
  font-weight: 500;
  color: rgba(255, 255, 255, 0.9);
`,O=i`
  padding: 12px 16px;
  border: 2px solid rgba(255, 255, 255, 0.2);
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.1);
  color: white;
  font-size: 16px;
  transition: all 0.2s ease;
  backdrop-filter: blur(10px);

  &::placeholder {
    color: rgba(255, 255, 255, 0.6);
  }

  &:focus {
    outline: none;
    border-color: rgba(255, 255, 255, 0.5);
    background: rgba(255, 255, 255, 0.15);
  }
`,U=i`
  padding: 14px 24px;
  background: rgba(255, 255, 255, 0.2);
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-radius: 8px;
  color: white;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  backdrop-filter: blur(10px);

  &:hover {
    background: rgba(255, 255, 255, 0.3);
    border-color: rgba(255, 255, 255, 0.5);
    transform: translateY(-1px);
  }

  &:active {
    transform: translateY(0);
  }

  &:disabled {
    opacity: 0.5;
    cursor: not-allowed;
    transform: none;
  }
`,H=i`
  font-size: 14px;
  text-align: center;
  min-height: 20px;
  color: rgba(255, 255, 255, 0.8);
`,J=i`
  color: #ff6b6b;
`,Q=i`
  color: #51cf66;
`;function V(s){const[n,x]=f(""),[l,t]=f(""),[r,c]=f(!1),[M,u]=f(""),[N,p]=f(!1),T=async e=>{if(e.preventDefault(),!n()||!l()){u("Please fill in all fields"),p(!0);return}c(!0),u("Logging in..."),p(!1);try{await new Promise(d=>setTimeout(d,1500)),s.onLogin&&s.onLogin({email:n(),password:l()}),u("Login successful!"),p(!1),await chrome.storage.local.set({userEmail:n(),isLoggedIn:!0,loginTime:Date.now()})}catch{u("Login failed. Please try again."),p(!0)}finally{c(!1)}};return A(async()=>{try{const e=await chrome.storage.local.get(["isLoggedIn","userEmail"]);e.isLoggedIn&&(u(`Welcome back, ${e.userEmail}!`),p(!1))}catch(e){console.error("Error checking login status:",e)}}),z(D.div,{class:j,initial:{opacity:0,scale:.9},animate:{opacity:1,scale:1},transition:{duration:.3,easing:"ease-out"},get children(){return[(()=>{var e=R();return a(e,G),e})(),(()=>{var e=W(),d=e.firstChild,L=d.firstChild,m=L.nextSibling,y=d.nextSibling,C=y.firstChild,b=C.nextSibling,v=y.nextSibling;return e.addEventListener("submit",T),a(e,K),a(d,_),a(L,I),m.$$input=o=>x(o.currentTarget.value),a(m,O),a(y,_),a(C,I),b.$$input=o=>t(o.currentTarget.value),a(b,O),a(v,U),S(v,()=>r()?"Logging in...":"Login"),h(o=>{var E=r(),$=r(),P=r();return E!==o.e&&(m.disabled=o.e=E),$!==o.t&&(b.disabled=o.t=$),P!==o.a&&(v.disabled=o.a=P),o},{e:void 0,t:void 0,a:void 0}),h(()=>m.value=n()),h(()=>b.value=l()),e})(),(()=>{var e=Y();return S(e,M),h(()=>a(e,`${H} ${N()?J:Q}`)),e})()]}})}q(["input"]);let g=null;function X(){const s=F();g&&(g.textContent=s)}function k(){const s=document.getElementById("app");if(!s){console.error("Popup app container not found");return}g=document.createElement("style"),g.setAttribute("data-styled-components",""),document.head.appendChild(g),B(()=>z(V,{onLogin:n=>{console.log("Login attempted with:",n.email)}}),s),X()}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",k):k();
