import{u as d,t as x,c as b,i as g,a as n,M as m,b as l,d as y,o as k,e as u,S as w,P as v,r as C,f as M}from"./index-DY_CammD.js";var E=x("<div>");const L=d`
  width: 50px;
  height: 50px;
  background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 11px;
  font-weight: 700;
  color: #ffffff;
  text-align: center;
  line-height: 1;
  box-shadow:
    0 8px 24px rgba(0, 0, 0, 0.25),
    0 4px 8px rgba(0, 0, 0, 0.15),
    inset 0 1px 0 rgba(255, 255, 255, 0.1);
  text-shadow: 0 1px 3px rgba(0, 0, 0, 0.5);
  border: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  -webkit-backdrop-filter: blur(10px);
`,S=t=>(()=>{var e=E();return b(e,L),g(e,()=>t.isMac?"⌘ + K":"Ctrl + K"),e})();var K=x("<div>");const O=d`
  width: 100%;
  padding: 12px 6px;
  background: linear-gradient(135deg, #212121 0%, #383838 100%);
  border-radius: 10px;
  margin-bottom: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 13px;
  font-weight: 600;
  color: #ffffff;
  text-align: center;
  line-height: 1;
  box-shadow:
    0 4px 16px rgba(0, 0, 0, 0.18),
    0 2px 4px rgba(0, 0, 0, 0.1),
    inset 0 1px 0 rgba(255, 255, 255, 0.07);
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.42);
  border: 1px solid rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(7px);
  -webkit-backdrop-filter: blur(7px);
  cursor: pointer;
`;function A({index:t,option:e,onClick:o}){return n(m.button,{class:O,onClick:o,initial:{opacity:0,scale:.8,x:80},animate:{opacity:1,scale:1,x:0},exit:{opacity:0,scale:.8,x:80},transition:{duration:.2,delay:t*.05,easing:"ease-out"},children:e})}const $=()=>{const t=()=>{console.log("Login clicked"),fetch("https://api.example.com/",{}).then(e=>e.json()).then(e=>{console.log(e)})};return(()=>{var e=K();return g(e,()=>n(A,{index:0,option:"Login",onClick:t})),e})()},j=d`
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 20px;
`,T=()=>{const t=navigator.userAgent.toLowerCase();return/macintosh|mac os x/.test(t)};function _(){const[t,e]=l(!1),[o,a]=l(!1),[r,f]=l(0),s=i=>{},c=i=>{if(!(o()?i.metaKey&&i.key==="k":i.ctrlKey&&i.key==="k"))return;i.preventDefault();const p=Date.now();p-r(),e(h=>!h),f(p)};return y(()=>{t()?document.addEventListener("click",s,!0):document.removeEventListener("click",s,!0)}),k(()=>{a(T()),document.addEventListener("keydown",c)}),u(()=>{document.addEventListener("keydown",c)}),u(()=>{document.removeEventListener("keydown",c),document.removeEventListener("click",s,!0)}),n(v,{exitBeforeEnter:!0,get children(){return n(w,{get when(){return t()},get children(){return n(m.div,{class:j,initial:{opacity:0,scale:.8,y:-20},animate:{opacity:1,scale:1,y:0},exit:{opacity:0,scale:.8,y:-20},transition:{duration:.2,easing:"ease-out"},get children(){return[n(S,{get isMac(){return o()}}),n($,{})]}})}})}})}function z(){const t=document.createElement("div");t.id="crxjs-app",document.body.appendChild(t);const e=t.attachShadow({mode:"open"}),o=document.createElement("div");e.appendChild(o);const a=document.createElement("style");e.appendChild(a);let r=C();console.log(r),a.textContent=r,M(()=>n(_,{}),e)}typeof chrome<"u"&&chrome.runtime&&chrome.runtime.id&&(console.log("Mounting app"),z());
